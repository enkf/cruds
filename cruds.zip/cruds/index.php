<?php
include './header/header.php';
include './sidebar/sidebar.php';
?>
<div class="continer">

    <div class="card-body">
        &nbsp;&nbsp;
        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
            + Tambah
        </button>

        <!-- Modal -->
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form action="" method="post" enctype="multipart/form-data" class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Data User</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form group-row">
                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                            <input type="text" name="names" id="names" class="form-control" style="text-transform:uppercase">
                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Telp</label>
                            <input type="number" name="telps" id="telps" class="form-control">
                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                            <textarea type="text" class="form-control" name="alamats" id="alamats"></textarea>
                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Status</label>
                            <select name="statused" id="statused" class="form-control">
                                <option>--Pilih Status--</option>
                                <option value="1">Aktif</option>
                                <option value="0">Tidak Aktif</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="table-responsive">
        <table id="data" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Telp</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include './config/koneksi.php';
                $no = 1;
                $SQL = "SELECT * FROM users";
                $cons = $koneksi->prepare($SQL);
                $cons->execute();
                $res = $cons->get_result();


                while ($row = $res->fetch_assoc()) {
                    $id = $row['id_user'];
                    $status = $row['status'];
                    $aktif = "Aktif";
                    $tidakaktif = "Tidak Aktif";
                    $urlDelete = "delete.php?idUser=".$id;

                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['no_telp'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                        <td> <?php if ($status == '1') {
                                    echo $aktif;
                                } else {
                                    echo $tidakaktif;
                                }
                                ?>
                        </td>
                        <td><button type="button" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo $row['id_user'] ?>">
                                <font color="#fff">Edit</font></button>
                                <a type="button" href="<?= $urlDelete ?>" class="btn btn-danger btn-sm">
                                Hapus</a></td>

                    </tr>

                    <div class="modal fade" id="exampleModal<?php echo $row['id_user']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Edit User</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form action="update.php" method="post" enctype="multipart/form-data">
                                    <div class="modal-body">
                                        <div class="form group-row">
                                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Nama</label>
                                            <input hidden type="text" name="id_user" id="id_user" class="form-control" value="<?= $row['id_user']; ?>">
                                            <input type="text" name="names" id="names" class="form-control" value="<?= $row['nama']; ?>">
                                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Telp</label>
                                            <input type="number" name="telps" id="telps" class="form-control" value="<?= $row['no_telp']; ?>">
                                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Alamat</label>
                                            <textarea type="text" class="form-control" name="alamats" id="alamats" value="<?= $row['alamat']; ?>"><?= $row['alamat']; ?></textarea>
                                            <label align="start" for="inputPassword" class="col-sm-2 col-form-label">Status</label>
                                            <select name="statused" id="statused" class="form-control">
                                                <?php
                                                $status = "Aktif";
                                                $statusnot = "Tidak Aktif";
                                              
                                                ?>
                                                <option value="<?= $row['status']; ?>">
                                                    <?php 
                                                     if($row['status'] =='1'){
                                                         echo $status;
                                                    }else{
                                                        echo $statusnot;
                                                    }
                                                    ?></option>
                                                <option value="1">Aktif</option>
                                                <option value="0">Tidak Aktif</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" name="update" class="btn btn-primary">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    <?php
                }
                    ?>
            </tbody>
        </table>
    </div>
</div>
</div>
<?php
include './config/koneksi.php';
if (!empty($_POST['names'])) {
    $names = $_POST['names'];
    $telps = $_POST['telps'];
    $alamats = $_POST['alamats'];
    $statused = $_POST['statused'];



    $dateInput = date('Y-m-d H:i:s');

    $SqlInsert = "INSERT INTO users(nama,no_telp,alamat,status,date_input) VALUES('$names','$telps','$alamats','$statused','$dateInput')";

    if (mysqli_query($koneksi, $SqlInsert)) {
        echo "<script type='text/javascript'>";
        echo "swal({
        title: 'Your Message Was Sent Successfully',
        type: 'success',

        confirmButtonColor: '#DD6B55',
        confirmButtonText: 'Close',
        }).then(() => {
          if (result.value) {
            // handle Confirm button click
          } else {
            // result.dismiss can be 'cancel', 'overlay', 'esc' or 'timer'
          }
        });";
        echo 'window.location="index.php"</script>';
    } else {
        echo "<script>
              Swal.fire({
                title: 'Error!',
                text: 'Data gagal disimpan.',
                icon: 'error',
                confirmButtonText: 'Coba lagi'
              });
            </script>";
    }
}
?>

<?php
include './footer/footer.php';
?>