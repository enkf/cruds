
<?php
include './config/koneksi.php';
if (isset($_POST['update'])) {
    $idUser = $_POST['id_user'];
    $names = $_POST['names'];
    $telps = $_POST['telps'];
    $alamats = $_POST['alamats'];
    $statused = $_POST['statused'];

    $SqlUPDATE = "UPDATE users SET nama='$names', no_telp='$telps', alamat='$alamats', status='$statused' WHERE id_user='$idUser'";

   
if (mysqli_query($koneksi, $SqlUPDATE)) {
    echo "<div class='spinner-border' role='status'>
          <span class='sr-only'>Data Berhasil Diupdate.!!!</span></div>";
  } else {
    echo "ERROR: Could not able to execute $SqlUPDATE. " . mysqli_error($koneksi);
  }
  
  
    echo '<meta http-equiv="Refresh" content="2; URL=index.php">';
  
}
?>
